package com.example.lista3

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.IntrinsicSize
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.RadioButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.lista3.ui.theme.Lista3Theme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            myApp()
        }
    }

    @Composable
    fun myApp() {
        var num_pyt by remember { mutableStateOf(1) }
        var wynik by remember { mutableStateOf(0) }
        var zaznaczonaOdpowiedz by remember { mutableStateOf<String?>(null) }
        var quizZakonczony by remember { mutableStateOf(false) }

        Column(
            modifier = Modifier.fillMaxWidth(),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            if (!quizZakonczony) {
                // Widok quizu podczas trwania
                Text("Pytanie $num_pyt/10", fontSize = 45.sp, fontWeight = FontWeight.Bold, textAlign = TextAlign.Center)
                LinearProgressIndicator(progress = (num_pyt * 0.1).toFloat(), modifier = Modifier
                    .fillMaxWidth()
                    .padding(50.dp))

                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(150.dp)
                        .padding(30.dp),
                    colors = CardDefaults.cardColors(containerColor = Color.LightGray)
                ) {
                    Text(baza.pytania[num_pyt - 1], fontSize = 25.sp)
                }

                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(350.dp)
                        .padding(20.dp)
                ) {
                    Column {
                        // Odpowiedź 1
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(75.dp)
                                .padding(10.dp)
                                .background(Color.LightGray)
                        ) {
                            RadioButton(
                                selected = zaznaczonaOdpowiedz == baza.odpowiedzi[num_pyt - 1][0],
                                onClick = {
                                    zaznaczonaOdpowiedz = baza.odpowiedzi[num_pyt - 1][0]
                                }
                            )
                            Text(
                                baza.odpowiedzi[num_pyt - 1][0],
                                fontSize = 30.sp,
                                fontWeight = FontWeight.Bold,
                            )
                        }

                        // Odpowiedź 2
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(75.dp)
                                .padding(10.dp)
                                .background(Color.LightGray)
                        ) {
                            RadioButton(
                                selected = zaznaczonaOdpowiedz == baza.odpowiedzi[num_pyt - 1][1],
                                onClick = {
                                    zaznaczonaOdpowiedz = baza.odpowiedzi[num_pyt - 1][1]
                                }
                            )
                            Text(
                                baza.odpowiedzi[num_pyt - 1][1],
                                fontSize = 30.sp,
                                fontWeight = FontWeight.Bold,
                            )
                        }

                        // Odpowiedź 3
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(75.dp)
                                .padding(10.dp)
                                .background(Color.LightGray)
                        ) {
                            RadioButton(
                                selected = zaznaczonaOdpowiedz == baza.odpowiedzi[num_pyt - 1][2],
                                onClick = {
                                    zaznaczonaOdpowiedz = baza.odpowiedzi[num_pyt - 1][2]
                                }
                            )
                            Text(
                                baza.odpowiedzi[num_pyt - 1][2],
                                fontSize = 30.sp,
                                fontWeight = FontWeight.Bold,
                            )
                        }

                        // Odpowiedź 4
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(75.dp)
                                .padding(10.dp)
                                .background(Color.LightGray)
                        ) {
                            RadioButton(
                                selected = zaznaczonaOdpowiedz == baza.odpowiedzi[num_pyt - 1][3],
                                onClick = {
                                    zaznaczonaOdpowiedz = baza.odpowiedzi[num_pyt - 1][3]
                                }
                            )
                            Text(
                                baza.odpowiedzi[num_pyt - 1][3],
                                fontSize = 30.sp,
                                fontWeight = FontWeight.Bold,
                            )
                        }
                    }
                }

                Button(modifier = Modifier.fillMaxWidth().padding(30.dp),onClick = {
                    if (num_pyt <= baza.pytania.size) {
                        val odpowiedz = zaznaczonaOdpowiedz ?: ""
                        if (odpowiedz == baza.poprawne[num_pyt - 1]) {
                            wynik += 10
                        }

                        num_pyt += 1
                        zaznaczonaOdpowiedz = null

                        if (num_pyt > baza.pytania.size) {
                            quizZakonczony = true
                        }
                    }
                }) {
                    Text("Następne")
                }
            } else {
                // Widok po zakończeniu quizu
                Text("Gratulacje!", fontSize = 45.sp, fontWeight = FontWeight.Bold, textAlign = TextAlign.Center, modifier = Modifier.padding(top=50.dp))

                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(600.dp)
                        .padding(50.dp)

                ) {
                    Column {
                        Text("Twój wynik: $wynik/100", fontSize = 35.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(top=200.dp))
                    }
                }
            }
        }
    }
}