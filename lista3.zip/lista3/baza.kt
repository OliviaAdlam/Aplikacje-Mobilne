package com.example.lista3

object baza {
    val pytania = arrayOf(
        "Jaką jednostkę ma natężenie prądu?",
        "Jaka jest stolica Niemiec?",
        "Ile wynosi 5! ?",
        "Ragdoll to rasa jakiego zwierzęcia?",
        "Ile jest podstawowych jednostek w ukadzie SI?",
        "Jaka jest najdłuższa rzeka na świecie?",
        "Ile wynosi 8:2(2+2)?",
        "Ile parków narodowych jest w Polsce?",
        "Jaka jest stolica Turcji?",
        "Ile jest kontynentów?"
    )

    val odpowiedzi = arrayOf(
        arrayOf("Wolt", "Amper", "Ohm", "Kilometr"),
        arrayOf("Frankfurt", "Warszawa", "Amsterdam", "Berlin"),
        arrayOf("120", "5", "500", "25"),
        arrayOf("psa", "kota", "królika", "konia"),
        arrayOf("7", "5", "20", "13"),
        arrayOf("Amazonka", "Nil", "Odra", "Dunaj"),
        arrayOf("8", "16", "10", "1"),
        arrayOf("17", "3", "23", "51"),
        arrayOf("Rabat", "Kair", "Ankara", "Istambuł"),
        arrayOf("11", "7", "5", "3")
    )

    val poprawne = arrayOf(
        "Amper",
        "Berlin",
        "120",
        "kota",
        "7",
        "Nil",
        "16",
        "23",
        "Ankara",
        "7"
    )
}



